public class ContohOperator10 {

    public static void main(String[] args) {
        int a = 60;
        int b = 20;
        int c = 10;
        
        System.out.println("Aritmatika  Operator");
        System.out.println("Bilangan a adalah" + a);
        System.out.println("Bilangan b adalah" + b);
        System.out.println("Bilangan c adalah" + c);
        System.out.println("a + b + c = " + (a + b + c));
        System.out.println("a - b - c = " +(a - b - c));
        System.out.println("a * c = " + (a * c));
        System.out.println("a / b = " + (a / b));
        System.out.println("a % b = " + (a % b));
        System.out.println("a + b * c = " + (a + b * c));
        System.out.println("(a + b) * c = " + ((a + b) * c));
    }
}